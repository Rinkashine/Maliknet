@extends('admin.layout.admin')
@section('content')
@section('title', 'Order')
<!-- Begin: List of Orders Table -->
<livewire:admin.transaction.order-table/>
<!-- End: List of Orders Table -->
@endsection
