@extends('admin.layout.admin')
@section('content')
@section('title', 'Account Verification Report')

<livewire:report.account-verification/>

@endsection
