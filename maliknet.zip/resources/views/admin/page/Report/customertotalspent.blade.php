@extends('admin.layout.admin')
@section('content')
@section('title', ' Customer Expenditure')

<livewire:report.customer-total-spent/>

@endsection
