@extends('admin.layout.admin')
@section('content')
@section('title', 'Customer Per Month')

<livewire:report.monthly-customer/>

@endsection

