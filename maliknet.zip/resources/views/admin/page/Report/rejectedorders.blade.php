@extends('admin.layout.admin')
@section('content')
@section('title', 'Rejected Orders Report')

<livewire:report.rejected-orders/>

@endsection
