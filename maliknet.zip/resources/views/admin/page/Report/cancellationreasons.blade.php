@extends('admin.layout.admin')
@section('content')
@section('title', 'Reasons for Cancelled Orders')

<livewire:report.cancellation-reasons/>

@endsection
