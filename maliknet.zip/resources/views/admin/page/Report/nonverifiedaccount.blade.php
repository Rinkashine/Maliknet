@extends('admin.layout.admin')
@section('content')
@section('title', 'Non-Verified Account Report')

<livewire:report.non-verified-account/>

@endsection
