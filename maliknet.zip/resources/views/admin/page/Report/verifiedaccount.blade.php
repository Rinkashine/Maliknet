@extends('admin.layout.admin')
@section('content')
@section('title', 'Verified Account Report')

<livewire:report.verified-account/>

@endsection
