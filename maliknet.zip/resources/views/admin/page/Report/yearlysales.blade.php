@extends('admin.layout.admin')
@section('content')
@section('title', 'Yearly Sales')

<livewire:report.yearly-sales/>

@endsection

