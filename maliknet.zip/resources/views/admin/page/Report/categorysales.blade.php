@extends('admin.layout.admin')
@section('content')
@section('title', 'Category Sales Report')

<livewire:report.category-sales/>

@endsection
