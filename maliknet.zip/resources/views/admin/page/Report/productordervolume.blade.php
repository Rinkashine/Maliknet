@extends('admin.layout.admin')
@section('content')
@section('title', 'Product Order Volume')

<livewire:report.product-order-volume/>

@endsection
