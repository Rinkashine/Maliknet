@extends('admin.layout.admin')
@section('content')
@section('title', 'Customer Order Volume')

<livewire:report.customer-order-volume/>

@endsection
