@extends('admin.layout.admin')
@section('content')
@section('title', 'Category Order Volume Report')

<livewire:report.category-order-volume/>

@endsection
