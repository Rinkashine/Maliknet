@extends('admin.layout.admin')
@section('content')
@section('title', 'Cancelled Orders Report')

<livewire:report.cancelled-orders/>

@endsection
