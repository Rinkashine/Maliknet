@extends('admin.layout.admin')
@section('content')
@section('title', 'Product Ratings')

<livewire:report.product-ratings/>

@endsection


