@extends('admin.layout.admin')
@section('content')
@section('title', 'Monthly Gained Customer')

<livewire:report.monthly-gained-customer/>

@endsection
