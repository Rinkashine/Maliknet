@extends('admin.layout.admin')
@section('content')
@section('title', 'Cancellation Over Time')

<livewire:report.cancellation-over-time/>

@endsection
