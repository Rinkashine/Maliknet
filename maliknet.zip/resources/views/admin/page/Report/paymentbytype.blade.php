@extends('admin.layout.admin')
@section('content')
@section('title', 'Payment By Type')

<livewire:report.payment-type/>


@endsection
