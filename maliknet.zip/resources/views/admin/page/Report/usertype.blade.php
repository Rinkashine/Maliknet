@extends('admin.layout.admin')
@section('content')
@section('title', 'User Type Report')

<livewire:report.user-type/>

@endsection


