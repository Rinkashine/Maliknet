@extends('admin.layout.admin')
@section('content')
@section('title', 'Monthly Sales')

<livewire:report.monthly-sales/>

@endsection

