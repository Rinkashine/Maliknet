@extends('admin.layout.admin')
@section('content')
@section('title', 'Product Sales')

<livewire:report.product-sales/>

@endsection
